-- OppoCash migration: opportunities + saved_opportunities, with Row Level Security.
-- Reuses public.skills_valid() and public.set_updated_at() from the previous migration.

create or replace function public.countries_valid(c text[]) returns boolean
language sql immutable as $$
  select c is not null and cardinality(c) <= 60
    and not exists (select 1 from unnest(c) x where x !~ '^[A-Z]{2}$');
$$;

create table public.opportunities (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 150),
  description text not null check (char_length(description) between 10 and 5000),
  organization text not null check (char_length(organization) between 2 and 120),
  opportunity_type text not null check (opportunity_type in
    ('scholarship','internship','job','freelance','skill_program','competition_grant','volunteering','services')),
  required_skills text[] not null default '{}' check (public.skills_valid(required_skills)),
  eligible_countries text[] not null default '{}' check (public.countries_valid(eligible_countries)), -- empty = open to all countries
  min_age int check (min_age between 0 and 120),
  max_age int check (max_age between 0 and 120),
  deadline date,
  location text check (char_length(location) <= 120),
  is_remote boolean not null default false,
  application_instructions text not null check (char_length(application_instructions) between 5 and 2000),
  source_url text not null check (source_url ~ '^https://[^[:space:]]+$' and char_length(source_url) <= 500),
  review_status text not null default 'pending' check (review_status in ('pending','approved','rejected','flagged')),
  last_checked_on date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (min_age is null or max_age is null or min_age <= max_age)
);
create index opportunities_status_created_idx on public.opportunities (review_status, created_at desc);
create index opportunities_type_idx on public.opportunities (opportunity_type);
create trigger opportunities_set_updated_at before update on public.opportunities
  for each row execute function public.set_updated_at();

alter table public.opportunities enable row level security;
revoke all on public.opportunities from anon, authenticated;
grant select on public.opportunities to anon, authenticated; -- read only; no write grants for API roles
create policy "opportunities: public reads approved only" on public.opportunities
  for select to anon, authenticated using (review_status = 'approved');

create table public.saved_opportunities (
  user_id uuid not null references auth.users(id) on delete cascade,
  opportunity_id uuid not null references public.opportunities(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, opportunity_id)
);
create index saved_opportunities_opportunity_idx on public.saved_opportunities (opportunity_id);

alter table public.saved_opportunities enable row level security;
revoke all on public.saved_opportunities from anon, authenticated;
grant select, delete on public.saved_opportunities to authenticated;
grant insert (user_id, opportunity_id) on public.saved_opportunities to authenticated;
create policy "saved: read own" on public.saved_opportunities
  for select to authenticated using (user_id = (select auth.uid()));
create policy "saved: delete own" on public.saved_opportunities
  for delete to authenticated using (user_id = (select auth.uid()));
-- The subquery runs under the caller's RLS, so only approved opportunities can be saved.
create policy "saved: insert own, approved only" on public.saved_opportunities
  for insert to authenticated with check (
    user_id = (select auth.uid())
    and exists (select 1 from public.opportunities o where o.id = opportunity_id and o.review_status = 'approved'));
