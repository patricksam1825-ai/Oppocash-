-- OppoCash migration: profiles + admin_users, with Row Level Security.
-- Run in the Supabase SQL editor (or `supabase db push`).

create or replace function public.skills_valid(s text[]) returns boolean
language sql immutable as $$
  select s is not null
    and coalesce(cardinality(s), 0) <= 15
    and not exists (select 1 from unnest(s) x where char_length(x) not between 2 and 30);
$$;

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;

-- Private profile. No role column: permissions never live on a row users can edit.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  country text not null check (country ~ '^[A-Z]{2}$'),
  age_bracket text not null check (age_bracket in ('13-15', '16-17', '18-19')),
  skills text[] not null default '{}' check (public.skills_valid(skills)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
-- Column-level grants: users cannot set id on update, or created_at/updated_at at all.
grant insert (id, display_name, country, age_bracket, skills) on public.profiles to authenticated;
grant update (display_name, country, age_bracket, skills) on public.profiles to authenticated;

create policy "profiles: read own" on public.profiles
  for select to authenticated using (id = (select auth.uid()));
create policy "profiles: insert own" on public.profiles
  for insert to authenticated with check (id = (select auth.uid()));
create policy "profiles: update own" on public.profiles
  for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- Administrators. Users can only see their own row; nobody can write through the API.
-- Add the first admin from the SQL editor (see README).
create table public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
revoke all on public.admin_users from anon, authenticated;
grant select on public.admin_users to authenticated;
create policy "admin_users: read own" on public.admin_users
  for select to authenticated using (user_id = (select auth.uid()));
