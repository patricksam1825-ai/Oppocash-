-- OppoCash migration: widen profiles.age_bracket to cover adults as well as teens.
-- Safe for an existing database: it only replaces the CHECK constraint, and every
-- existing value ('13-15', '16-17', '18-19') stays valid. Exact birth dates are still not stored.
do $$
declare c record;
begin
  for c in
    select conname from pg_constraint
    where conrelid = 'public.profiles'::regclass and contype = 'c'
      and pg_get_constraintdef(oid) like '%age_bracket%'
  loop
    execute format('alter table public.profiles drop constraint %I', c.conname);
  end loop;
end $$;

alter table public.profiles add constraint profiles_age_bracket_check
  check (age_bracket in ('13-15', '16-17', '18-19', '20-29', '30-44', '45-59', '60+'));
