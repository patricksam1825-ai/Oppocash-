-- RLS tests for profiles and admin_users.
-- Run in the SQL editor of a TEST Supabase project, after ALL migrations (T12 needs the age-bracket migration).
-- Everything rolls back: the script ends with an intentional error whose message
-- is the result list. Read the PASS/FAIL lines in that message.
begin;

create function public.__rec(t text, s text) returns void language sql as $$
  select set_config('t.results', coalesce(current_setting('t.results', true), '') || t || ' => ' || s || E'\n', true)
$$;
create function public.__expect_fail(t text, q text) returns void language plpgsql as $$
begin
  execute q;
  perform public.__rec(t, 'FAIL: statement was allowed');
exception when others then
  perform public.__rec(t, 'PASS (blocked: ' || sqlerrm || ')');
end $$;
create function public.__expect_rows(t text, q text, want int) returns void language plpgsql as $$
declare n int;
begin
  execute q;
  get diagnostics n = row_count;
  perform public.__rec(t, case when n = want then 'PASS' else 'FAIL: got ' || n || ' rows, wanted ' || want end);
exception when others then
  perform public.__rec(t, 'FAIL: ' || sqlerrm);
end $$;

insert into auth.users (id, email) values
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'a@test.local'),
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'b@test.local');
insert into public.profiles (id, display_name, country, age_bracket)
  values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Bee', 'NG', '16-17');

-- Act as ordinary user A
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"authenticated"}', true);

select public.__expect_rows('T1 user inserts own profile', $q$insert into public.profiles (id, display_name, country, age_bracket, skills) values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Ay', 'NG', '13-15', array['python'])$q$, 1);
select public.__expect_fail('T2 user cannot insert a profile for another user', $q$insert into public.profiles (id, display_name, country, age_bracket) values ('cccccccc-cccc-cccc-cccc-cccccccccccc', 'Fake', 'NG', '13-15')$q$);
select public.__expect_rows('T3 user cannot read another user profile', $q$select * from public.profiles where id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$q$, 0);
select public.__expect_rows('T4 user can read own profile', $q$select * from public.profiles where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$, 1);
select public.__expect_rows('T5 user cannot update another user profile', $q$update public.profiles set display_name = 'Hacked' where id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$q$, 0);
select public.__expect_fail('T6 user cannot change own id', $q$update public.profiles set id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$);
select public.__expect_fail('T7 user cannot edit created_at', $q$update public.profiles set created_at = now() - interval '1 year' where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$);
select public.__expect_fail('T8 invalid age bracket is rejected', $q$update public.profiles set age_bracket = '9-12' where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$);
select public.__expect_fail('T9 user cannot make themselves admin', $q$insert into public.admin_users (user_id) values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')$q$);
select public.__expect_fail('T10 user cannot delete admin rows', $q$delete from public.admin_users$q$);

select public.__expect_rows('T12 user can choose an adult age group (60+)', $q$update public.profiles set age_bracket = '60+' where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$, 1);
select public.__expect_fail('T13 unknown age group is rejected', $q$update public.profiles set age_bracket = '12-14' where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$);

-- Act as a signed-out visitor
reset role;
set local role anon;
select set_config('request.jwt.claims', '{"role":"anon"}', true);
select public.__expect_fail('T11 signed-out visitor cannot read profiles', $q$select * from public.profiles$q$);
reset role;

do $$ begin raise exception E'RLS TEST RESULTS (everything rolled back)\n%', current_setting('t.results'); end $$;
