-- RLS tests for opportunities and saved_opportunities. Run in a TEST project after both migrations.
-- Ends with an intentional error whose message lists the results; everything rolls back.
begin;
create function public.__rec(t text, s text) returns void language sql as $$
  select set_config('t.results', coalesce(current_setting('t.results', true), '') || t || ' => ' || s || E'\n', true) $$;
create function public.__expect_fail(t text, q text) returns void language plpgsql as $$
begin execute q; perform public.__rec(t, 'FAIL: statement was allowed');
exception when others then perform public.__rec(t, 'PASS (blocked: ' || sqlerrm || ')'); end $$;
create function public.__expect_rows(t text, q text, want int) returns void language plpgsql as $$
declare n int;
begin execute q; get diagnostics n = row_count;
  perform public.__rec(t, case when n = want then 'PASS' else 'FAIL: got ' || n || ' rows, wanted ' || want end);
exception when others then perform public.__rec(t, 'FAIL: ' || sqlerrm); end $$;

insert into auth.users (id, email) values
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'a@test.local'), ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'b@test.local');
insert into public.opportunities (id, title, description, organization, opportunity_type, application_instructions, source_url, review_status) values
  ('11111111-1111-1111-1111-111111111111', 'Test approved', 'Test description text', 'Test Org', 'competition_grant', 'Apply on the site', 'https://example.org/a', 'approved'),
  ('22222222-2222-2222-2222-222222222222', 'Test pending', 'Test description text', 'Test Org', 'competition_grant', 'Apply on the site', 'https://example.org/b', 'pending');
insert into public.saved_opportunities (user_id, opportunity_id)
  values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '11111111-1111-1111-1111-111111111111');

-- Constraint checks (as table owner)
select public.__expect_fail('T1 non-https source_url is rejected', $q$insert into public.opportunities (title, description, organization, opportunity_type, application_instructions, source_url) values ('Bad link','Test description text','Org','job','Apply here','http://example.org')$q$);
select public.__expect_fail('T2 min_age above max_age is rejected', $q$insert into public.opportunities (title, description, organization, opportunity_type, application_instructions, source_url, min_age, max_age) values ('Bad ages','Test description text','Org','job','Apply here','https://example.org',19,13)$q$);

-- Signed-out visitor
set local role anon;
select set_config('request.jwt.claims', '{"role":"anon"}', true);
select public.__expect_rows('T3 visitor sees approved opportunities only', $q$select * from public.opportunities$q$, 1);
select public.__expect_fail('T4 visitor cannot read saved_opportunities', $q$select * from public.saved_opportunities$q$);
select public.__expect_fail('T5 visitor cannot insert an opportunity', $q$insert into public.opportunities (title, description, organization, opportunity_type, application_instructions, source_url, review_status) values ('Spam','Test description text','Org','job','Apply here','https://example.org','approved')$q$);
reset role;

-- Ordinary user A
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa","role":"authenticated"}', true);
select public.__expect_rows('T6 user cannot see a pending opportunity', $q$select * from public.opportunities where id = '22222222-2222-2222-2222-222222222222'$q$, 0);
select public.__expect_fail('T7 user cannot approve an opportunity', $q$update public.opportunities set review_status = 'approved' where id = '22222222-2222-2222-2222-222222222222'$q$);
select public.__expect_fail('T8 user cannot insert an opportunity', $q$insert into public.opportunities (title, description, organization, opportunity_type, application_instructions, source_url, review_status) values ('Spam','Test description text','Org','job','Apply here','https://example.org','approved')$q$);
select public.__expect_fail('T9 user cannot delete an opportunity', $q$delete from public.opportunities$q$);
select public.__expect_rows('T10 user saves an approved opportunity', $q$insert into public.saved_opportunities (user_id, opportunity_id) values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','11111111-1111-1111-1111-111111111111')$q$, 1);
select public.__expect_fail('T11 user cannot save a pending opportunity', $q$insert into public.saved_opportunities (user_id, opportunity_id) values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','22222222-2222-2222-2222-222222222222')$q$);
select public.__expect_fail('T12 user cannot save on behalf of another user', $q$insert into public.saved_opportunities (user_id, opportunity_id) values ('cccccccc-cccc-cccc-cccc-cccccccccccc','11111111-1111-1111-1111-111111111111')$q$);
select public.__expect_rows('T13 user cannot read another user''s saved rows', $q$select * from public.saved_opportunities where user_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$q$, 0);
select public.__expect_rows('T14 user cannot delete another user''s saved rows', $q$delete from public.saved_opportunities where user_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$q$, 0);
select public.__expect_rows('T15 user unsaves their own', $q$delete from public.saved_opportunities where user_id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'$q$, 1);
reset role;

do $$ begin raise exception E'RLS TEST RESULTS (everything rolled back)\n%', current_setting('t.results'); end $$;
