// Age and country eligibility tests. Run: npm test (needs Node 22.6 or newer).
import test from 'node:test'
import assert from 'node:assert/strict'
import { checkEligibility, bracketRange } from '../src/lib/opportunities.ts'

const BRACKETS = ['13-15', '16-17', '18-19', '20-29', '30-44', '45-59', '60+']
const opp = (min_age, max_age, eligible_countries = []) => ({ min_age, max_age, eligible_countries })
const age = (bracket, o) => checkEligibility(o, { country: 'NG', ageBracket: bracket }).age

test('bracketRange parses every bracket without NaN', () => {
  for (const b of BRACKETS) {
    const r = bracketRange(b)
    assert.ok(r && !Number.isNaN(r.lo) && !Number.isNaN(r.hi), b)
  }
  assert.deepEqual(bracketRange('60+'), { lo: 60, hi: Infinity })
  assert.equal(bracketRange('abc'), null)
  assert.equal(bracketRange('15-13'), null)
})
test('listing with no age limits matches every bracket', () => {
  for (const b of BRACKETS) assert.equal(age(b, opp(null, null)), true, b)
})
test('teen listing (13-19)', () => {
  for (const b of ['13-15', '16-17', '18-19']) assert.equal(age(b, opp(13, 19)), true, b)
  for (const b of ['20-29', '30-44', '45-59', '60+']) assert.equal(age(b, opp(13, 19)), false, b)
})
test('listing for 16 and up excludes 13-15 only', () => {
  assert.equal(age('13-15', opp(16, null)), false)
  for (const b of BRACKETS.slice(1)) assert.equal(age(b, opp(16, null)), true, b)
})
test('adult listing 20-29', () => {
  assert.equal(age('18-19', opp(20, 29)), false)
  assert.equal(age('20-29', opp(20, 29)), true)
  assert.equal(age('30-44', opp(20, 29)), false)
})
test('listing 30-44', () => {
  assert.equal(age('20-29', opp(30, 44)), false)
  assert.equal(age('30-44', opp(30, 44)), true)
  assert.equal(age('45-59', opp(30, 44)), false)
})
test('listing 45-70 (retired and older adults)', () => {
  assert.equal(age('30-44', opp(45, 70)), false)
  assert.equal(age('45-59', opp(45, 70)), true)
  assert.equal(age('60+', opp(45, 70)), true)
})
test('60+ handled at the open end', () => {
  assert.equal(age('60+', opp(60, null)), true)
  assert.equal(age('60+', opp(65, null)), true)
  assert.equal(age('60+', opp(null, 59)), false)
  assert.equal(age('60+', opp(13, 19)), false)
  assert.equal(age('45-59', opp(60, null)), false)
})
test('exact boundaries', () => {
  assert.equal(age('18-19', opp(null, 17)), false)
  assert.equal(age('18-19', opp(null, 18)), true)
  assert.equal(age('45-59', opp(null, 44)), false)
  assert.equal(age('20-29', opp(30, null)), false)
})
test('unknown age group never excludes and never gives NaN', () => {
  assert.equal(checkEligibility(opp(13, 19), { country: 'NG', ageBracket: 'abc' }).age, true)
})
test('no profile means nothing is excluded', () => {
  assert.deepEqual(checkEligibility(opp(13, 19, ['GH']), null), { age: true, country: true })
})
test('country rules', () => {
  const c = (o, country) => checkEligibility(o, { country, ageBracket: '20-29' }).country
  assert.equal(c(opp(null, null, []), 'NG'), true)
  assert.equal(c(opp(null, null, ['NG', 'GH']), 'NG'), true)
  assert.equal(c(opp(null, null, ['GH']), 'NG'), false)
})
