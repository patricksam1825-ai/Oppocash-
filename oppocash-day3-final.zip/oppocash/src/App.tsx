import { Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import AuthForm from './components/AuthForm'
import Landing from './pages/Landing'
import Profile from './pages/Profile'
import Opportunities from './pages/Opportunities'
import OpportunityDetail from './pages/OpportunityDetail'
import StubPage from './pages/StubPage'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Landing />} />
        <Route path="opportunities" element={<Opportunities />} />
        <Route path="opportunities/:id" element={<OpportunityDetail />} />
        <Route path="login" element={<AuthForm mode="login" />} />
        <Route path="signup" element={<AuthForm mode="signup" />} />
        <Route element={<ProtectedRoute />}>
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="*" element={<StubPage title="Page not found" />} />
      </Route>
    </Routes>
  )
}
