import { useState, type FormEvent } from 'react'
import { Link, Navigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { validateEmail, validatePassword } from '../lib/validation'
import Field, { inputCls } from './Field'
import NotConfigured from './NotConfigured'

function friendly(msg: string) {
  const m = msg.toLowerCase()
  if (m.includes('invalid login')) return 'Email or password is incorrect.'
  if (m.includes('not confirmed')) return 'Verify your email first. Check your inbox for the link.'
  if (m.includes('rate limit')) return 'Too many attempts. Wait a few minutes and try again.'
  return 'Something went wrong. Check your connection and try again.'
}

export default function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const { session } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [is13, setIs13] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const [sent, setSent] = useState(false)
  const signup = mode === 'signup'

  if (session) return <Navigate to="/profile" replace />
  if (!supabase) return <NotConfigured />
  const sb = supabase

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const errs: Record<string, string> = {}
    const em = validateEmail(email)
    if (em) errs.email = em
    const pw = signup ? validatePassword(password) : password ? '' : 'Enter your password.'
    if (pw) errs.password = pw
    if (signup && !is13) errs.is13 = 'You must be 13 or older to use OppoCash.'
    setErrors(errs)
    if (Object.keys(errs).length) return
    setBusy(true)
    const res = signup
      ? await sb.auth.signUp({ email: email.trim(), password, options: { emailRedirectTo: `${window.location.origin}/login` } })
      : await sb.auth.signInWithPassword({ email: email.trim(), password })
    setBusy(false)
    if (res.error) { setErrors({ form: friendly(res.error.message) }); return }
    if (signup && !res.data.session) setSent(true)
  }

  if (sent) {
    return (
      <section className="max-w-md" role="status">
        <h1 className="text-3xl font-extrabold">Check your email</h1>
        <p className="mt-3">If this address can be registered, a verification link is on its way. Open it, then sign in.</p>
        <Link to="/login" className="mt-5 inline-block rounded bg-forest px-4 py-2 font-semibold text-white">Go to sign in</Link>
      </section>
    )
  }

  return (
    <section className="max-w-md">
      <h1 className="text-3xl font-extrabold">{signup ? 'Create your free account' : 'Sign in'}</h1>
      <form onSubmit={onSubmit} noValidate className="mt-2">
        {errors.form && <p role="alert" className="mt-3 rounded border-2 border-red-700 bg-white p-3 text-sm font-semibold text-red-700">{errors.form}</p>}
        <Field id="email" label="Email" error={errors.email}>
          <input id="email" type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)}
            aria-invalid={Boolean(errors.email)} aria-describedby="email-note" className={inputCls} />
        </Field>
        <Field id="password" label="Password" hint={signup ? 'At least 8 characters.' : undefined} error={errors.password}>
          <input id="password" type="password" autoComplete={signup ? 'new-password' : 'current-password'} value={password}
            onChange={(e) => setPassword(e.target.value)} aria-invalid={Boolean(errors.password)} aria-describedby="password-note" className={inputCls} />
        </Field>
        {signup && (
          <div className="mt-4">
            <label className="flex items-start gap-2 text-sm font-semibold">
              <input type="checkbox" checked={is13} onChange={(e) => setIs13(e.target.checked)} className="mt-1 h-5 w-5" />
              I am 13 years old or older.
            </label>
            {errors.is13 && <p role="alert" className="mt-1 text-sm font-semibold text-red-700">{errors.is13}</p>}
          </div>
        )}
        <button type="submit" disabled={busy} className="mt-6 w-full rounded bg-forest px-4 py-3 font-bold text-white disabled:opacity-60">
          {busy ? 'Please wait…' : signup ? 'Create account' : 'Sign in'}
        </button>
      </form>
      <p className="mt-4 text-sm">
        {signup ? <>Already have an account? <Link to="/login" className="font-bold text-forest underline">Sign in</Link></>
          : <>New here? <Link to="/signup" className="font-bold text-forest underline">Create an account</Link></>}
      </p>
    </section>
  )
}
