import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'

const link = ({ isActive }: { isActive: boolean }) =>
  `rounded px-3 py-2 text-sm font-semibold ${isActive ? 'bg-forest text-white' : 'text-forest hover:bg-forest/10'}`

export default function Layout() {
  const { session } = useAuth()
  const navigate = useNavigate()

  async function signOut() {
    await supabase?.auth.signOut()
    navigate('/')
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-forest/15 bg-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-2 px-4 py-3">
          <Link to="/" className="text-xl font-extrabold tracking-tight text-forest">OppoCash</Link>
          <nav aria-label="Main" className="flex flex-wrap gap-1">
            <NavLink to="/opportunities" className={link}>Opportunities</NavLink>
            {session ? (
              <>
                <NavLink to="/profile" className={link}>Profile</NavLink>
                <button onClick={signOut} className="rounded px-3 py-2 text-sm font-semibold text-forest hover:bg-forest/10">Sign out</button>
              </>
            ) : (
              <NavLink to="/login" className={link}>Sign in</NavLink>
            )}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8"><Outlet /></main>
      <footer className="border-t border-forest/15 px-4 py-4 text-center text-sm text-ink/70">
        Hackathon build. Always confirm eligibility on the original source before you apply.
      </footer>
    </div>
  )
}
