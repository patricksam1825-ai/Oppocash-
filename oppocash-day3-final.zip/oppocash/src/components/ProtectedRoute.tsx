import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { isSupabaseConfigured } from '../lib/supabase'
import NotConfigured from './NotConfigured'

export default function ProtectedRoute() {
  const { session, loading } = useAuth()
  const location = useLocation()
  if (!isSupabaseConfigured) return <NotConfigured />
  if (loading) return <p role="status">Loading your account…</p>
  if (!session) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  return <Outlet />
}
