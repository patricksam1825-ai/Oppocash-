import type { ReactNode } from 'react'

export const inputCls = 'mt-1 w-full rounded border-2 border-forest/40 bg-white px-3 py-2 text-base'

export default function Field({ id, label, hint, error, children }: {
  id: string; label: string; hint?: string; error?: string; children: ReactNode
}) {
  return (
    <div className="mt-4">
      <label htmlFor={id} className="block text-sm font-bold">{label}</label>
      {children}
      {hint && !error && <p id={`${id}-note`} className="mt-1 text-sm text-ink/70">{hint}</p>}
      {error && <p id={`${id}-note`} role="alert" className="mt-1 text-sm font-semibold text-red-700">{error}</p>}
    </div>
  )
}
