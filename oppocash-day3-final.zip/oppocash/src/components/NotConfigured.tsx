export default function NotConfigured() {
  return (
    <div role="alert" className="max-w-xl rounded border-2 border-marigold bg-white p-4">
      <p className="font-bold">Supabase is not configured.</p>
      <p className="mt-1 text-sm">
        Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file (see the README), then restart the dev server.
        Sign in and profiles stay disabled until then.
      </p>
    </div>
  )
}
