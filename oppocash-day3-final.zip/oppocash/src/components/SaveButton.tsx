import { Link } from 'react-router-dom'

export default function SaveButton({ saved, signedIn, onToggle }: { saved: boolean; signedIn: boolean; onToggle: () => void }) {
  if (!signedIn) return <Link to="/login" className="text-sm font-bold text-forest underline">Sign in to save</Link>
  return (
    <button type="button" onClick={onToggle} aria-pressed={saved}
      className={`rounded border-2 border-forest px-3 py-1 text-sm font-bold ${saved ? 'bg-forest text-white' : 'text-forest'}`}>
      {saved ? 'Saved' : 'Save'}
    </button>
  )
}
