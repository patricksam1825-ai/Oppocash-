import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { COUNTRIES } from '../lib/validation'
import { COLUMNS, TYPE_LABELS, ageText, checkEligibility, fmtDate, isClosed, safeUrl, type Opportunity } from '../lib/opportunities'
import { useMyEligibility, useSaved } from '../lib/hub'
import NotConfigured from '../components/NotConfigured'
import SaveButton from '../components/SaveButton'

export default function OpportunityDetail() {
  const { id } = useParams()
  const me = useMyEligibility()
  const saved = useSaved()
  const [o, setO] = useState<Opportunity | null>(null)
  const [loading, setLoading] = useState(Boolean(supabase))
  const [error, setError] = useState('')

  useEffect(() => {
    if (!supabase || !id) return
    supabase.from('opportunities').select(COLUMNS).eq('id', id).eq('review_status', 'approved').maybeSingle()
      .then(({ data, error: e }) => {
        if (e) setError('Could not load this opportunity. Check your connection and try again.')
        else setO(data as Opportunity | null)
        setLoading(false)
      })
  }, [id])

  if (!supabase) return <NotConfigured />
  if (loading) return <p role="status">Loading…</p>
  if (error) return <p role="alert" className="font-semibold text-red-700">{error}</p>
  if (!o) return (
    <section>
      <h1 className="text-2xl font-extrabold">Opportunity not found</h1>
      <p className="mt-2">It may have been removed or is not published.</p>
      <Link to="/opportunities" className="mt-4 inline-block rounded bg-forest px-4 py-2 font-bold text-white">Back to the Hub</Link>
    </section>
  )

  const e = checkEligibility(o, me)
  const countries = o.eligible_countries.length ? o.eligible_countries.map((c) => COUNTRIES[c] ?? c).join(', ') : 'Open to all countries'
  return (
    <article className="max-w-2xl">
      <Link to="/opportunities" className="text-sm font-bold text-forest underline">All opportunities</Link>
      <p className="mt-4 text-xs font-bold text-forest">{TYPE_LABELS[o.opportunity_type] ?? o.opportunity_type}</p>
      <h1 className="mt-1 text-3xl font-extrabold">{o.title}</h1>
      <p className="text-ink/70">{o.organization}</p>
      <p className="mt-3 inline-block rounded bg-marigold px-2 py-1 text-sm font-bold">
        Approved listing. Last checked: {o.last_checked_on ? fmtDate(o.last_checked_on) : 'date not recorded'}
      </p>
      {isClosed(o) && <p className="mt-3 font-bold text-red-700">The deadline for this opportunity has passed.</p>}
      {me && (!e.age || !e.country) && <p className="mt-3 font-semibold text-red-700">This may not match your {!e.age ? 'age group' : 'country'}. Check the official source.</p>}
      {me && e.age && e.country && <p className="mt-3 font-semibold text-forest">Matches your age group and country, based on the listing.</p>}

      <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        <div><dt className="font-bold">Deadline</dt><dd>{o.deadline ? fmtDate(o.deadline) : 'No deadline listed'}</dd></div>
        <div><dt className="font-bold">Location</dt><dd>{[o.location, o.is_remote ? 'Remote' : ''].filter(Boolean).join(', ') || 'Not listed'}</dd></div>
        <div><dt className="font-bold">Age</dt><dd>{ageText(o)}</dd></div>
        <div><dt className="font-bold">Countries</dt><dd>{countries}</dd></div>
        <div className="sm:col-span-2"><dt className="font-bold">Required skills</dt><dd>{o.required_skills.length ? o.required_skills.join(', ') : 'None listed'}</dd></div>
      </dl>

      <h2 className="mt-6 text-xl font-bold">About</h2>
      <p className="mt-1 whitespace-pre-wrap">{o.description}</p>
      <h2 className="mt-6 text-xl font-bold">How to apply</h2>
      <p className="mt-1 whitespace-pre-wrap">{o.application_instructions}</p>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        {safeUrl(o.source_url) && (
          <a href={o.source_url} target="_blank" rel="noopener noreferrer" className="rounded bg-forest px-4 py-3 font-bold text-white">Open official source</a>
        )}
        <SaveButton saved={saved.ids.has(o.id)} signedIn={saved.signedIn} onToggle={() => saved.toggle(o.id)} />
      </div>
      {saved.error && <p role="alert" className="mt-3 text-sm font-semibold text-red-700">{saved.error}</p>}
    </article>
  )
}
