import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { COUNTRIES } from '../lib/validation'
import { COLUMNS, TYPE_LABELS, checkEligibility, fmtDate, isClosed, type Opportunity } from '../lib/opportunities'
import { useMyEligibility, useSaved } from '../lib/hub'
import NotConfigured from '../components/NotConfigured'
import SaveButton from '../components/SaveButton'
import { inputCls } from '../components/Field'

export default function Opportunities() {
  const me = useMyEligibility()
  const saved = useSaved()
  const [items, setItems] = useState<Opportunity[]>([])
  const [loading, setLoading] = useState(Boolean(supabase))
  const [error, setError] = useState('')
  const [q, setQ] = useState('')
  const [type, setType] = useState('')
  const [country, setCountry] = useState('')
  const [eligibleOnly, setEligibleOnly] = useState(true)
  const [savedOnly, setSavedOnly] = useState(false)

  useEffect(() => {
    if (!supabase) return
    supabase.from('opportunities').select(COLUMNS).eq('review_status', 'approved')
      .order('created_at', { ascending: false }).limit(500)
      .then(({ data, error: e }) => {
        if (e) setError('Could not load opportunities. Check your connection and refresh.')
        else setItems((data ?? []) as Opportunity[])
        setLoading(false)
      })
  }, [])

  if (!supabase) return <NotConfigured />

  const needle = q.trim().toLowerCase()
  const list = items.filter((o) => {
    if (type && o.opportunity_type !== type) return false
    if (country && o.eligible_countries.length > 0 && !o.eligible_countries.includes(country)) return false
    if (needle && !`${o.title} ${o.description} ${o.organization} ${o.required_skills.join(' ')}`.toLowerCase().includes(needle)) return false
    if (eligibleOnly && me) { const e = checkEligibility(o, me); if (!e.age || !e.country) return false }
    if (savedOnly && !saved.ids.has(o.id)) return false
    return true
  }).sort((a, b) => Number(isClosed(a)) - Number(isClosed(b)))

  const clear = () => { setQ(''); setType(''); setCountry(''); setSavedOnly(false); setEligibleOnly(true) }

  return (
    <section>
      <h1 className="text-3xl font-extrabold">Opportunity Hub</h1>
      <p className="mt-1 text-sm text-ink/70">Only approved listings appear here. Always confirm details on the official source.</p>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <div className="sm:col-span-3">
          <label htmlFor="q" className="block text-sm font-bold">Search</label>
          <input id="q" type="search" value={q} onChange={(e) => setQ(e.target.value)} maxLength={80}
            placeholder="Title, organisation, description or skill" className={inputCls} />
        </div>
        <div>
          <label htmlFor="type" className="block text-sm font-bold">Type</label>
          <select id="type" value={type} onChange={(e) => setType(e.target.value)} className={inputCls}>
            <option value="">All types</option>
            {Object.entries(TYPE_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-bold">Country</label>
          <select id="country" value={country} onChange={(e) => setCountry(e.target.value)} className={inputCls}>
            <option value="">Any country</option>
            {Object.entries(COUNTRIES).sort((a, b) => a[1].localeCompare(b[1])).map(([c, n]) => <option key={c} value={c}>{n}</option>)}
          </select>
        </div>
        <div className="flex flex-col justify-end gap-2 text-sm font-semibold">
          {me && (
            <label className="flex items-center gap-2">
              <input type="checkbox" className="h-5 w-5" checked={eligibleOnly} onChange={(e) => setEligibleOnly(e.target.checked)} />
              Only what I am eligible for
            </label>
          )}
          {saved.signedIn && (
            <label className="flex items-center gap-2">
              <input type="checkbox" className="h-5 w-5" checked={savedOnly} onChange={(e) => setSavedOnly(e.target.checked)} />
              Saved only
            </label>
          )}
        </div>
      </div>
      {saved.signedIn && !me && !loading && (
        <p className="mt-3 text-sm"><Link to="/profile" className="font-bold text-forest underline">Set up your profile</Link> to filter by your age group and country.</p>
      )}
      {(error || saved.error) && <p role="alert" className="mt-3 rounded border-2 border-red-700 bg-white p-3 text-sm font-semibold text-red-700">{error || saved.error}</p>}

      <p className="mt-4 text-sm" role="status" aria-live="polite">{loading ? 'Loading opportunities…' : `${list.length} shown`}</p>

      {!loading && !error && items.length === 0 && (
        <p className="mt-4 rounded border-2 border-forest bg-white p-4">No approved opportunities have been published yet. Listings are added only after they are checked against their official source.</p>
      )}
      {!loading && items.length > 0 && list.length === 0 && (
        <div className="mt-4 rounded border-2 border-forest bg-white p-4">
          <p>No opportunities match your search and filters.</p>
          <button type="button" onClick={clear} className="mt-3 rounded bg-forest px-4 py-2 text-sm font-bold text-white">Clear filters</button>
        </div>
      )}

      <ul className="mt-4 grid gap-4 md:grid-cols-2">
        {list.map((o) => {
          const e = checkEligibility(o, me)
          return (
            <li key={o.id} className="flex flex-col rounded-lg border-2 border-forest/30 bg-white p-4">
              <p className="text-xs font-bold text-forest">{TYPE_LABELS[o.opportunity_type] ?? o.opportunity_type}</p>
              <h2 className="mt-1 text-lg font-bold"><Link to={`/opportunities/${o.id}`} className="underline">{o.title}</Link></h2>
              <p className="text-sm text-ink/70">{o.organization}</p>
              <p className="mt-2 text-sm">
                {isClosed(o) ? <span className="rounded bg-ink px-2 py-0.5 font-bold text-white">Deadline passed</span>
                  : o.deadline ? `Deadline: ${fmtDate(o.deadline)}` : 'No deadline listed'}
              </p>
              {me && (!e.age || !e.country) && (
                <p className="mt-2 text-sm font-semibold text-red-700">May not match your {!e.age && !e.country ? 'age group or country' : !e.age ? 'age group' : 'country'}.</p>
              )}
              {o.required_skills.length > 0 && <p className="mt-2 text-sm">Skills: {o.required_skills.slice(0, 5).join(', ')}</p>}
              <div className="mt-auto pt-3"><SaveButton saved={saved.ids.has(o.id)} signedIn={saved.signedIn} onToggle={() => saved.toggle(o.id)} /></div>
            </li>
          )
        })}
      </ul>
    </section>
  )
}
