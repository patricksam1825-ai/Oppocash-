import { Link } from 'react-router-dom'

const AUDIENCES = [
  { who: 'Teenagers', what: 'Look for competitions, programmes and first experience that fit your age group.' },
  { who: 'Working-age adults', what: 'Look for freelance work, skills programmes and routes into a new field.' },
  { who: 'Retired adults', what: 'Look for volunteering, part-time work and ways to put your experience to use.' },
  { who: 'People facing barriers to work', what: 'Look for flexible, remote and skills-based options, whatever your background.' },
]

const PEOPLE = [
  { who: 'A 17-year-old in Nigeria', ok: true },
  { who: 'A 62-year-old in Ghana', ok: true },
  { who: 'A 14-year-old in Nigeria', ok: false },
]

export default function Landing() {
  return (
    <div>
      <div className="grid gap-10 md:grid-cols-2 md:items-center">
        <section>
          <h1 className="text-4xl font-extrabold leading-tight md:text-5xl">
            Skills first. Opportunities that fit you.
          </h1>
          <p className="mt-4 max-w-md text-lg">
            OppoCash is for people of every age, from teenagers to retired adults. It checks your age group, country and skills, so you see opportunities you can actually apply for.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/signup" className="rounded bg-forest px-5 py-3 font-bold text-white">Create free account</Link>
            <Link to="/opportunities" className="rounded border-2 border-forest px-5 py-3 font-bold text-forest">Browse opportunities</Link>
          </div>
          <p className="mt-4 text-sm text-ink/70">Free to use. Accounts are for people aged 13 and over.</p>
        </section>

        <section aria-label="Demonstration of how eligibility matching reads" className="rounded-lg border-2 border-forest bg-white p-5">
          <p className="inline-block rounded bg-marigold px-2 py-1 text-sm font-bold">Demonstration only: fictional listing and people</p>
          <h2 className="mt-3 text-xl font-bold">Remote data-entry training programme</h2>
          <ul className="mt-3 flex flex-wrap gap-2 text-sm font-semibold">
            <li className="rounded bg-forest/10 px-2 py-1 text-forest">Ages 16 and over</li>
            <li className="rounded bg-forest/10 px-2 py-1 text-forest">Open to Nigeria and Ghana</li>
            <li className="rounded bg-forest/10 px-2 py-1 text-forest">Online</li>
          </ul>
          <p className="mt-4 text-sm font-bold">How OppoCash would read it for different people:</p>
          <ul className="mt-2 grid gap-2 text-sm">
            {PEOPLE.map((p) => (
              <li key={p.who} className="flex flex-wrap justify-between gap-x-3">
                <span>{p.who}</span>
                <span className={p.ok ? 'font-semibold text-forest' : 'font-semibold text-red-700'}>
                  {p.ok ? 'Matches age group and country' : 'May not match age group'}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-ink/70">This is not a real opportunity. Real listings show their official source and the date we last checked it.</p>
        </section>
      </div>

      <section className="mt-12" aria-labelledby="who-heading">
        <h2 id="who-heading" className="text-2xl font-extrabold">Who OppoCash is for</h2>
        <ul className="mt-4 grid gap-4 sm:grid-cols-2">
          {AUDIENCES.map((a) => (
            <li key={a.who} className="rounded-lg border-2 border-forest/30 bg-white p-4">
              <h3 className="font-bold text-forest">{a.who}</h3>
              <p className="mt-1 text-sm">{a.what}</p>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-ink/70">Your skills are your starting point, not your wallet.</p>
      </section>
    </div>
  )
}
