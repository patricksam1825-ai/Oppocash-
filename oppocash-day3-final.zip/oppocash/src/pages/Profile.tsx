import { useEffect, useState, type FormEvent } from 'react'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import { AGE_BRACKETS, AGE_LABELS, COUNTRIES, validateProfile } from '../lib/validation'
import Field, { inputCls } from '../components/Field'

export default function Profile() {
  const { session } = useAuth()
  const uid = session?.user.id
  const [loading, setLoading] = useState(true)
  const [exists, setExists] = useState(false)
  const [name, setName] = useState('')
  const [country, setCountry] = useState('')
  const [bracket, setBracket] = useState('')
  const [skillsText, setSkillsText] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    if (!supabase || !uid) return
    let live = true
    supabase.from('profiles').select('display_name,country,age_bracket,skills').eq('id', uid).maybeSingle()
      .then(({ data, error }) => {
        if (!live) return
        if (error) setErrors({ form: 'Could not load your profile. Check your connection and refresh.' })
        else if (data) {
          setExists(true); setName(data.display_name); setCountry(data.country)
          setBracket(data.age_bracket); setSkillsText((data.skills as string[]).join(', '))
        }
        setLoading(false)
      })
    return () => { live = false }
  }, [uid])

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setMsg('')
    if (!supabase || !uid) return
    const { values, errors: errs } = validateProfile({ name, country, bracket, skillsText })
    setErrors(errs)
    if (!values) return
    setSaving(true)
    const row = { display_name: values.displayName, country: values.country, age_bracket: values.ageBracket, skills: values.skills }
    const { error } = exists
      ? await supabase.from('profiles').update(row).eq('id', uid)
      : await supabase.from('profiles').insert({ id: uid, ...row })
    setSaving(false)
    if (error) { setErrors({ form: 'Could not save your profile. Please try again.' }); return }
    setExists(true)
    setMsg('Profile saved.')
  }

  if (loading) return <p role="status">Loading your profile…</p>

  return (
    <section className="max-w-md">
      <h1 className="text-3xl font-extrabold">{exists ? 'Your profile' : 'Set up your profile'}</h1>
      {!exists && <p className="mt-2">Add a few details so OppoCash can match you with opportunities you are eligible for.</p>}
      <p className="mt-2 text-sm text-ink/70">Signed in as {session?.user.email}. Your email and age group stay private.</p>
      <form onSubmit={onSubmit} noValidate>
        {errors.form && <p role="alert" className="mt-3 rounded border-2 border-red-700 bg-white p-3 text-sm font-semibold text-red-700">{errors.form}</p>}
        {msg && <p role="status" className="mt-3 rounded border-2 border-forest bg-white p-3 text-sm font-semibold text-forest">{msg}</p>}
        <Field id="name" label="Display name" error={errors.name}>
          <input id="name" maxLength={40} autoComplete="nickname" value={name} onChange={(e) => setName(e.target.value)}
            aria-invalid={Boolean(errors.name)} aria-describedby="name-note" className={inputCls} />
        </Field>
        <Field id="country" label="Country" error={errors.country}>
          <select id="country" value={country} onChange={(e) => setCountry(e.target.value)}
            aria-invalid={Boolean(errors.country)} aria-describedby="country-note" className={inputCls}>
            <option value="">Choose a country</option>
            {Object.entries(COUNTRIES).sort((a, b) => a[1].localeCompare(b[1])).map(([c, n]) => <option key={c} value={c}>{n}</option>)}
          </select>
        </Field>
        <Field id="bracket" label="Age group" hint="Used only to check eligibility. Never shown publicly." error={errors.bracket}>
          <select id="bracket" value={bracket} onChange={(e) => setBracket(e.target.value)}
            aria-invalid={Boolean(errors.bracket)} aria-describedby="bracket-note" className={inputCls}>
            <option value="">Choose your age group</option>
            {AGE_BRACKETS.map((b) => <option key={b} value={b}>{AGE_LABELS[b]}</option>)}
          </select>
        </Field>
        <Field id="skills" label="Skills" hint="Separate with commas, for example: Python, graphic design, writing." error={errors.skills}>
          <input id="skills" value={skillsText} onChange={(e) => setSkillsText(e.target.value)}
            aria-invalid={Boolean(errors.skills)} aria-describedby="skills-note" className={inputCls} />
        </Field>
        <button type="submit" disabled={saving} className="mt-6 w-full rounded bg-forest px-4 py-3 font-bold text-white disabled:opacity-60">
          {saving ? 'Saving…' : exists ? 'Save changes' : 'Save profile'}
        </button>
      </form>
    </section>
  )
}
