import { Link } from 'react-router-dom'

export default function StubPage({ title, day }: { title: string; day?: number }) {
  return (
    <section className="max-w-xl">
      <h1 className="text-3xl font-extrabold">{title}</h1>
      <p className="mt-3">
        {day ? `This screen is not built yet. It is planned for Day ${day}.` : 'Check the address, or go back to the home page.'}
      </p>
      <Link to="/" className="mt-5 inline-block rounded bg-forest px-4 py-2 font-semibold text-white">Back to home</Link>
    </section>
  )
}
