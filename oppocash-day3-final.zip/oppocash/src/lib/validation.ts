export const COUNTRIES: Record<string, string> = {
  NG: 'Nigeria', GH: 'Ghana', KE: 'Kenya', ZA: 'South Africa', EG: 'Egypt', TZ: 'Tanzania',
  UG: 'Uganda', RW: 'Rwanda', US: 'United States', GB: 'United Kingdom', CA: 'Canada',
  IN: 'India', AU: 'Australia',
}
export const AGE_BRACKETS = ['13-15', '16-17', '18-19', '20-29', '30-44', '45-59', '60+'] as const
export const AGE_LABELS: Record<string, string> = {
  '13-15': '13 to 15', '16-17': '16 to 17', '18-19': '18 to 19', '20-29': '20 to 29',
  '30-44': '30 to 44', '45-59': '45 to 59', '60+': '60 and over',
}

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const SKILL = /^[\p{L}\p{N} +#.\-]{2,30}$/u

export const validateEmail = (v: string) =>
  EMAIL.test(v.trim()) && v.trim().length <= 254 ? '' : 'Enter a valid email address.'

export const validatePassword = (v: string) =>
  v.length < 8 ? 'Use at least 8 characters.' : v.length > 72 ? 'Use 72 characters or fewer.' : ''

export function parseSkills(text: string): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const raw of text.split(',')) {
    const s = raw.trim().replace(/\s+/g, ' ')
    if (s && !seen.has(s.toLowerCase())) { seen.add(s.toLowerCase()); out.push(s) }
  }
  return out
}

export function validateProfile(i: { name: string; country: string; bracket: string; skillsText: string }) {
  const errors: Record<string, string> = {}
  const displayName = i.name.trim().replace(/\s+/g, ' ')
  if (displayName.length < 2 || displayName.length > 40) errors.name = 'Display name must be 2 to 40 characters.'
  if (!Object.keys(COUNTRIES).includes(i.country)) errors.country = 'Choose your country.'
  if (!(AGE_BRACKETS as readonly string[]).includes(i.bracket)) errors.bracket = 'Choose your age group.'
  const skills = parseSkills(i.skillsText)
  if (skills.length > 15) errors.skills = 'Add 15 skills or fewer.'
  else if (skills.some((s) => !SKILL.test(s))) errors.skills = 'Each skill must be 2 to 30 characters: letters, numbers, spaces, + # . -'
  if (Object.keys(errors).length) return { errors, values: null }
  return { errors, values: { displayName, country: i.country, ageBracket: i.bracket, skills } }
}
