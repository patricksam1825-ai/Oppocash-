export const TYPE_LABELS: Record<string, string> = {
  scholarship: 'Scholarships and education',
  internship: 'Internships and work experience',
  job: 'Jobs and employment',
  freelance: 'Freelance',
  skill_program: 'Skill-development programs',
  competition_grant: 'Competitions and grants',
  volunteering: 'Volunteering',
  services: 'Offer your services',
}

export type Opportunity = {
  id: string; title: string; description: string; organization: string; opportunity_type: string
  required_skills: string[]; eligible_countries: string[]; min_age: number | null; max_age: number | null
  deadline: string | null; location: string | null; is_remote: boolean
  application_instructions: string; source_url: string; last_checked_on: string | null
}

export const COLUMNS = 'id,title,description,organization,opportunity_type,required_skills,eligible_countries,min_age,max_age,deadline,location,is_remote,application_instructions,source_url,last_checked_on'

export type Eligibility = { country: string; ageBracket: string } | null

export function bracketRange(b: string): { lo: number; hi: number } | null {
  const open = /^(\d{1,3})\+$/.exec(b)
  if (open) return { lo: Number(open[1]), hi: Infinity }
  const span = /^(\d{1,3})-(\d{1,3})$/.exec(b)
  if (span && Number(span[1]) <= Number(span[2])) return { lo: Number(span[1]), hi: Number(span[2]) }
  return null
}

// An opportunity matches when its age range overlaps the user's age group, so nobody explicitly
// eligible is hidden. An unrecognised age group is never used to exclude a listing.
export function checkEligibility(o: Pick<Opportunity, 'min_age' | 'max_age' | 'eligible_countries'>, me: Eligibility) {
  if (!me) return { age: true, country: true }
  const r = bracketRange(me.ageBracket)
  const age = !r || ((o.min_age == null || o.min_age <= r.hi) && (o.max_age == null || o.max_age >= r.lo))
  const country = o.eligible_countries.length === 0 || o.eligible_countries.includes(me.country)
  return { age, country }
}

export const isClosed = (o: Opportunity) => o.deadline != null && o.deadline < new Date().toISOString().slice(0, 10)
export const safeUrl = (u: string) => u.startsWith('https://')
export const fmtDate = (d: string) =>
  new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
export const ageText = (o: Opportunity) =>
  o.min_age == null && o.max_age == null ? 'No age limit listed'
  : o.min_age != null && o.max_age != null ? `Ages ${o.min_age} to ${o.max_age}`
  : o.min_age != null ? `Ages ${o.min_age} and up` : `Up to age ${o.max_age}`
