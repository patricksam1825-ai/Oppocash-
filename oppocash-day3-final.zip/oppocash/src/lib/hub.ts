import { useCallback, useEffect, useState } from 'react'
import { supabase } from './supabase'
import { useAuth } from './auth'
import type { Eligibility } from './opportunities'

export function useMyEligibility(): Eligibility {
  const uid = useAuth().session?.user.id
  const [me, setMe] = useState<Eligibility>(null)
  useEffect(() => {
    if (!supabase || !uid) { setMe(null); return }
    let live = true
    supabase.from('profiles').select('country,age_bracket').eq('id', uid).maybeSingle()
      .then(({ data }) => { if (live) setMe(data ? { country: data.country, ageBracket: data.age_bracket } : null) })
    return () => { live = false }
  }, [uid])
  return me
}

export function useSaved() {
  const uid = useAuth().session?.user.id
  const [ids, setIds] = useState<Set<string>>(new Set())
  const [error, setError] = useState('')
  useEffect(() => {
    if (!supabase || !uid) { setIds(new Set()); return }
    let live = true
    supabase.from('saved_opportunities').select('opportunity_id').then(({ data, error: e }) => {
      if (!live) return
      if (e) setError('Could not load your saved list.')
      else setIds(new Set((data ?? []).map((r) => r.opportunity_id as string)))
    })
    return () => { live = false }
  }, [uid])
  const toggle = useCallback(async (oppId: string) => {
    if (!supabase || !uid) return
    setError('')
    const was = ids.has(oppId)
    const next = new Set(ids)
    if (was) next.delete(oppId); else next.add(oppId)
    setIds(next)
    const { error: e } = was
      ? await supabase.from('saved_opportunities').delete().eq('opportunity_id', oppId).eq('user_id', uid)
      : await supabase.from('saved_opportunities').insert({ user_id: uid, opportunity_id: oppId })
    if (e) { setIds(ids); setError('Could not update your saved list. Please try again.') }
  }, [ids, uid])
  return { ids, toggle, error, signedIn: Boolean(uid) }
}
