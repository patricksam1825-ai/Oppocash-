# OppoCash

Helps people of every age find legitimate opportunities that match their skills, age group and country. The audience includes teenagers, adults of all ages, retired people, and anyone who struggles to find traditional work despite having valuable skills. Built for EurekaDev 2026 (Coding Track).

## Status
- Day 1: app shell, routing, landing page, Netlify config.
- Day 2: Supabase email/password auth, email verification, sign out, protected routes, private profiles with Row Level Security.
- Day 3: Opportunity Hub (browse, search, filter, detail page, save and unsave) backed by RLS. No listings are bundled: the Hub is empty until real, checked listings are added.
- Not built yet: password reset, admin review queue, matching.

## Supabase setup
1. Create a project at supabase.com. Use a separate TEST project for the RLS tests.
2. SQL Editor: paste `supabase/migrations/20261012000000_profiles_and_admin_users.sql` and run it.
3. Project Settings > API: copy the Project URL and the anon public key. Never use the service_role key in this project.
4. Authentication > Providers: Email enabled, "Confirm email" ON.
5. Authentication > URL Configuration: set Site URL to `http://localhost:5173` and add your Netlify URL under Redirect URLs once deployed.
6. Copy `.env.example` to `.env` and fill in the two values:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
7. On Netlify, add the same two variables under Site configuration > Environment variables.

Supabase's built-in email sender has a low hourly limit. For the judging period, plan custom SMTP or a demo account.

## Run locally
```
npm install
npm run typecheck
npm run build
npm run dev
```

## First administrator (used from Day 5)
Admins are never created through the app. After that person signs up, run this in the SQL editor:
```
insert into public.admin_users (user_id) select id from auth.users where email = 'admin@example.com';
```

## Security tests
`supabase/tests/rls_profiles.sql` runs 11 checks as two ordinary users and a signed-out visitor, then rolls back. Run it in a TEST project; results appear in the error message at the end.

## Test status (update after running)
| Test | Status |
|---|---|
| TypeScript check and production build | NOT TESTED |
| Sign up, email verification, login, logout | NOT TESTED |
| Session persists after refresh | NOT TESTED |
| Profile create and edit | NOT TESTED |
| RLS tests T1 to T11 | NOT TESTED |

## Day 3: Opportunity Hub
Run `supabase/migrations/20261013000000_opportunities.sql` in the SQL editor, then `supabase/tests/rls_opportunities.sql` in the TEST project.

Public visitors see only rows with `review_status = 'approved'`. Until the admin screen exists (Day 5), add a listing from the SQL editor, only after checking its official page:
```
insert into public.opportunities (title, description, organization, opportunity_type, required_skills, eligible_countries, min_age, max_age, deadline, location, is_remote, application_instructions, source_url, review_status, last_checked_on)
values ('<title>', '<description>', '<organisation>', 'competition_grant', '{}', '{NG}', 13, 19, null, 'Online', true, '<how to apply>', 'https://<official-url>', 'approved', current_date);
```
Types: scholarship, internship, job, freelance, skill_program, competition_grant, volunteering, services. An empty `eligible_countries` means open to all countries.

| Day 3 test | Status |
|---|---|
| TypeScript check and production build | NOT TESTED |
| Hub browse, search, filters, detail page | NOT TESTED |
| Save and unsave in the browser | NOT TESTED |
| RLS tests T1 to T15 (opportunities) | NOT TESTED |

## Day 3 fix: all age groups
Age groups are now 13-15, 16-17, 18-19, 20-29, 30-44, 45-59 and 60+. Only the group is stored, never a birth date.
Existing databases: run `supabase/migrations/20261014000000_expand_age_brackets.sql` (it only replaces the CHECK constraint, existing profiles stay valid). New databases run all migrations in order.

Eligibility rule: a listing matches when its age range overlaps the user's age group. An unrecognised group never hides a listing.

| Test | Status |
|---|---|
| Age eligibility unit tests (`npm test`, 12 tests, all 7 groups, 60+, boundaries) | PASS (12 of 12, run on Node 22) |
| TypeScript check and production build | NOT TESTED |
| Profile age dropdown and save in the browser | NOT TESTED |
| RLS tests T1 to T13 (profiles, includes new age groups) | NOT TESTED |
| RLS tests T1 to T15 (opportunities) | NOT TESTED |
