export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { forest: '#0B5D3B', marigold: '#FFB703', ink: '#14231C', paper: '#F3F6FA' } } },
  plugins: [],
}
